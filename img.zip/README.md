# MVP - Front

Este pequeno projeto faz parte do MVP da Disciplina **Desenvolvimento Full Stack Básico** 



---
## Como executar

Basta fazer o download do projeto e abrir o arquivo index.html no seu browser.
